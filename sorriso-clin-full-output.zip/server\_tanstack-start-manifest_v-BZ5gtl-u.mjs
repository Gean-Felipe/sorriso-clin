//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BZ5gtl-u.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/geanf/OneDrive/Desktop/Sorriso Clin/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-jwkVOsWB.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-jwkVOsWB.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/geanf/OneDrive/Desktop/Sorriso Clin/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BW8sCp-i.js"]
	}
} });
//#endregion
export { tsrStartManifest };
