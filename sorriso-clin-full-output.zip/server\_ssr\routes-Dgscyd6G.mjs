import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { C as AlignHorizontalDistributeCenter, S as Anchor, _ as HeartHandshake, a as Star, b as Award, c as ShieldCheck, d as MoveHorizontal, f as Menu, g as HeartPulse, h as Instagram, i as Stethoscope, l as Quote, m as Layers, n as UserRound, o as Sparkles, p as MapPin, r as Sun, s as Smile, t as X, u as Phone, v as HandHeart, x as ArrowRight, y as Cpu } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dgscyd6G.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
			destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
			outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
			secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
			ghost: "hover:bg-accent hover:text-accent-foreground",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-9 px-4 py-2",
			sm: "h-8 rounded-md px-3 text-xs",
			lg: "h-10 rounded-md px-8",
			icon: "h-9 w-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var img = {
	logo: {
		version: 1,
		asset_id: "62fffe5f-19b9-44b9-a7cb-7e23e0027046",
		project_id: "6c776cf4-1925-46e3-866c-8cca2c47ea24",
		url: "/__l5e/assets-v1/62fffe5f-19b9-44b9-a7cb-7e23e0027046/logo-sorrisoclin.png",
		r2_key: "a/v1/6c776cf4-1925-46e3-866c-8cca2c47ea24/62fffe5f-19b9-44b9-a7cb-7e23e0027046/logo-sorrisoclin.png",
		original_filename: "logo-sorrisoclin.png",
		size: 218156,
		content_type: "image/png",
		created_at: "2026-08-23T16:46:44Z"
	}.url,
	logoBranco: {
		version: 1,
		asset_id: "9d2b5008-7edc-458a-9b5a-892fb66118f3",
		project_id: "6c776cf4-1925-46e3-866c-8cca2c47ea24",
		url: "/__l5e/assets-v1/9d2b5008-7edc-458a-9b5a-892fb66118f3/logo-sorrisoclin-branco.png",
		r2_key: "a/v1/6c776cf4-1925-46e3-866c-8cca2c47ea24/9d2b5008-7edc-458a-9b5a-892fb66118f3/logo-sorrisoclin-branco.png",
		original_filename: "logo-sorrisoclin-branco.png",
		size: 65806,
		content_type: "image/png",
		created_at: "2026-08-23T16:46:47Z"
	}.url,
	dentistaJaleco: {
		version: 1,
		asset_id: "2f735f05-0e2c-46fb-85b9-97774f4be04d",
		project_id: "6c776cf4-1925-46e3-866c-8cca2c47ea24",
		url: "/__l5e/assets-v1/2f735f05-0e2c-46fb-85b9-97774f4be04d/dentista-jaleco.jpg",
		r2_key: "a/v1/6c776cf4-1925-46e3-866c-8cca2c47ea24/2f735f05-0e2c-46fb-85b9-97774f4be04d/dentista-jaleco.jpg",
		original_filename: "dentista-jaleco.jpg",
		size: 96734,
		content_type: "image/jpeg",
		created_at: "2026-08-23T16:45:15Z"
	}.url,
	profissionalMagenta: {
		version: 1,
		asset_id: "438b7232-03fa-479c-8c9c-2493341f2c51",
		project_id: "6c776cf4-1925-46e3-866c-8cca2c47ea24",
		url: "/__l5e/assets-v1/438b7232-03fa-479c-8c9c-2493341f2c51/profissional-magenta.jpg",
		r2_key: "a/v1/6c776cf4-1925-46e3-866c-8cca2c47ea24/438b7232-03fa-479c-8c9c-2493341f2c51/profissional-magenta.jpg",
		original_filename: "profissional-magenta.jpg",
		size: 151732,
		content_type: "image/jpeg",
		created_at: "2026-08-23T16:45:19Z"
	}.url,
	sedacao: {
		version: 1,
		asset_id: "43b58a92-8e1b-46b0-8dd5-419e574740c8",
		project_id: "6c776cf4-1925-46e3-866c-8cca2c47ea24",
		url: "/__l5e/assets-v1/43b58a92-8e1b-46b0-8dd5-419e574740c8/sedacao-consciente.jpg",
		r2_key: "a/v1/6c776cf4-1925-46e3-866c-8cca2c47ea24/43b58a92-8e1b-46b0-8dd5-419e574740c8/sedacao-consciente.jpg",
		original_filename: "sedacao-consciente.jpg",
		size: 115957,
		content_type: "image/jpeg",
		created_at: "2026-08-23T16:45:23Z"
	}.url,
	sorrisoPaciente: {
		version: 1,
		asset_id: "82419812-e31e-4bcf-a359-89575e3eae3d",
		project_id: "6c776cf4-1925-46e3-866c-8cca2c47ea24",
		url: "/__l5e/assets-v1/82419812-e31e-4bcf-a359-89575e3eae3d/sorriso-paciente.jpg",
		r2_key: "a/v1/6c776cf4-1925-46e3-866c-8cca2c47ea24/82419812-e31e-4bcf-a359-89575e3eae3d/sorriso-paciente.jpg",
		original_filename: "sorriso-paciente.jpg",
		size: 551331,
		content_type: "image/jpeg",
		created_at: "2026-08-23T16:45:27Z"
	}.url,
	antesDepois: {
		version: 1,
		asset_id: "be0c31bf-dcad-4da2-a39b-ce95db82735b",
		project_id: "6c776cf4-1925-46e3-866c-8cca2c47ea24",
		url: "/__l5e/assets-v1/be0c31bf-dcad-4da2-a39b-ce95db82735b/antes-depois.jpg",
		r2_key: "a/v1/6c776cf4-1925-46e3-866c-8cca2c47ea24/be0c31bf-dcad-4da2-a39b-ce95db82735b/antes-depois.jpg",
		original_filename: "antes-depois.jpg",
		size: 266088,
		content_type: "image/jpeg",
		created_at: "2026-08-23T16:45:31Z"
	}.url,
	fotografiaOdonto: {
		version: 1,
		asset_id: "ab5d2123-8ec1-42d8-901b-56457bd11660",
		project_id: "6c776cf4-1925-46e3-866c-8cca2c47ea24",
		url: "/__l5e/assets-v1/ab5d2123-8ec1-42d8-901b-56457bd11660/fotografia-odontologica.jpg",
		r2_key: "a/v1/6c776cf4-1925-46e3-866c-8cca2c47ea24/ab5d2123-8ec1-42d8-901b-56457bd11660/fotografia-odontologica.jpg",
		original_filename: "fotografia-odontologica.jpg",
		size: 266884,
		content_type: "image/jpeg",
		created_at: "2026-08-23T16:45:35Z"
	}.url,
	casoAntes: {
		version: 1,
		asset_id: "7ee3c773-928e-4c53-b852-d085adb7dbfc",
		project_id: "6c776cf4-1925-46e3-866c-8cca2c47ea24",
		url: "/__l5e/assets-v1/7ee3c773-928e-4c53-b852-d085adb7dbfc/caso-antes.jpg",
		r2_key: "a/v1/6c776cf4-1925-46e3-866c-8cca2c47ea24/7ee3c773-928e-4c53-b852-d085adb7dbfc/caso-antes.jpg",
		original_filename: "caso-antes.jpg",
		size: 56741,
		content_type: "image/jpeg",
		created_at: "2026-08-23T16:47:22Z"
	}.url,
	casoDepois: {
		version: 1,
		asset_id: "b102fe44-6739-47ce-8344-e06f127a10c2",
		project_id: "6c776cf4-1925-46e3-866c-8cca2c47ea24",
		url: "/__l5e/assets-v1/b102fe44-6739-47ce-8344-e06f127a10c2/caso-depois.jpg",
		r2_key: "a/v1/6c776cf4-1925-46e3-866c-8cca2c47ea24/b102fe44-6739-47ce-8344-e06f127a10c2/caso-depois.jpg",
		original_filename: "caso-depois.jpg",
		size: 58355,
		content_type: "image/jpeg",
		created_at: "2026-08-23T16:47:25Z"
	}.url
};
var clinica = {
	nome: "Sorriso Clin",
	endereco: "Av. Gonçalo Botelho de Campos, 2446",
	bairro: "Cristo Rei — Várzea Grande — MT",
	cep: "78118-070",
	telefone: "(65) 3685-7299",
	telefoneLink: "tel:+556536857299",
	instagram: "https://www.instagram.com/sorrisoclin_varzeagrande/",
	nota: "4,5",
	avaliacoes: 27,
	mapsBusca: "https://www.google.com/maps/search/?api=1&query=Av.+Gon%C3%A7alo+Botelho+de+Campos%2C+2446+-+Cristo+Rei%2C+V%C3%A1rzea+Grande+-+MT%2C+78118-070",
	mapsRota: "https://www.google.com/maps/dir/?api=1&destination=Av.+Gon%C3%A7alo+Botelho+de+Campos%2C+2446+-+Cristo+Rei%2C+V%C3%A1rzea+Grande+-+MT%2C+78118-070",
	mapsEmbed: "https://www.google.com/maps?q=Av.%20Gon%C3%A7alo%20Botelho%20de%20Campos%2C%202446%20-%20Cristo%20Rei%2C%20V%C3%A1rzea%20Grande%20-%20MT%2C%2078118-070&output=embed"
};
var nav = [
	{
		label: "Início",
		href: "#inicio"
	},
	{
		label: "A Clínica",
		href: "#clinica"
	},
	{
		label: "Tratamentos",
		href: "#tratamentos"
	},
	{
		label: "Equipe",
		href: "#equipe"
	},
	{
		label: "Resultados",
		href: "#resultados"
	},
	{
		label: "Contato",
		href: "#contato"
	}
];
function Header() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 12);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	(0, import_react.useEffect)(() => {
		document.body.style.overflow = open ? "hidden" : "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: cn("fixed inset-x-0 top-0 z-50 transition-all duration-300", scrolled ? "border-b border-border/70 bg-background/90 backdrop-blur-md" : "bg-transparent"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-4 py-3 sm:px-6 lg:py-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#inicio",
					className: "flex min-w-0 items-center",
					"aria-label": "Sorriso Clin — início",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: img.logo,
						alt: "Logo Sorriso Clin",
						className: "h-9 w-auto shrink-0 sm:h-10",
						width: 936,
						height: 324
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					"aria-label": "Navegação principal",
					className: "hidden items-center gap-1 lg:flex",
					children: [nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: item.href,
						className: "rounded-md px-3 py-2 text-sm font-medium text-foreground/80 transition-colors hover:text-primary focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none",
						children: item.label
					}, item.href)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						className: "ml-3 rounded-full px-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#contato",
							children: "Agendar consulta"
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 lg:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "icon",
						variant: "outline",
						className: "min-h-11 min-w-11 rounded-full",
						"aria-label": `Ligar para ${clinica.telefone}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: clinica.telefoneLink,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: "ghost",
						className: "min-h-11 min-w-11",
						"aria-label": open ? "Fechar menu" : "Abrir menu",
						"aria-expanded": open,
						onClick: () => setOpen((v) => !v),
						children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
					})]
				})
			]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-border bg-background lg:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				"aria-label": "Navegação mobile",
				className: "mx-auto max-w-7xl px-4 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col",
					children: nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: item.href,
						onClick: () => setOpen(false),
						className: "block rounded-lg px-2 py-3 text-base font-medium text-foreground transition-colors hover:bg-secondary",
						children: item.label
					}) }, item.href))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "mt-3 h-12 w-full rounded-full text-base",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#contato",
						onClick: () => setOpen(false),
						children: "Agendar consulta"
					})
				})]
			})
		})]
	});
}
/** Elemento gráfico inspirado no arco/sorriso do logo Sorriso Clin. */
function Arc({ className, stroke = "currentColor", width = 2 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 400 60",
		fill: "none",
		"aria-hidden": "true",
		preserveAspectRatio: "none",
		className: cn("pointer-events-none select-none", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M4 6C60 46 140 56 200 56C260 56 340 46 396 6",
			stroke,
			strokeWidth: width,
			strokeLinecap: "round"
		})
	});
}
/** Divisor de seção com o arco da marca. */
function ArcDivider({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex items-center justify-center gap-4 py-2", className),
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px w-16 bg-border sm:w-24" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arc, {
				className: "h-4 w-20 text-primary",
				width: 4
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px w-16 bg-border sm:w-24" })
		]
	});
}
function Reveal({ children, className, delay = 0, as: Tag = "div" }) {
	const ref = (0, import_react.useRef)(null);
	const [shown, setShown] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		const io = new IntersectionObserver((entries) => {
			for (const e of entries) if (e.isIntersecting) {
				setShown(true);
				io.disconnect();
			}
		}, {
			threshold: .12,
			rootMargin: "0px 0px -40px 0px"
		});
		io.observe(el);
		return () => io.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
		ref,
		style: delay ? { transitionDelay: `${delay}ms` } : void 0,
		className: cn("reveal", shown && "reveal-in", className),
		children
	});
}
var indicadores = [
	{
		icon: Sparkles,
		label: "Experiência"
	},
	{
		icon: Cpu,
		label: "Tecnologia"
	},
	{
		icon: HeartHandshake,
		label: "Atendimento humanizado"
	}
];
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "inicio",
		className: "relative overflow-hidden bg-ice pt-28 pb-16 lg:pt-36 lg:pb-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arc, {
			className: "absolute -top-24 left-1/2 h-72 w-[140%] -translate-x-1/2 text-soft",
			width: 1.2
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-[1.05fr_0.95fr] lg:gap-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "inline-flex items-center gap-2 rounded-full border border-primary/20 bg-background px-4 py-1.5 text-xs font-semibold tracking-wide text-primary uppercase",
					children: "Odontologia em Várzea Grande — MT"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "mt-6 text-4xl leading-[1.05] font-extrabold sm:text-5xl xl:text-6xl",
					children: [
						"Mais que estética.",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "relative inline-block",
							children: ["Devolvemos confiança", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arc, {
								className: "absolute -bottom-3 left-0 h-4 w-full text-magenta",
								width: 5
							})]
						}),
						" ",
						"ao seu sorriso."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg",
					children: "Na Sorriso Clin, unimos experiência, tecnologia e cuidado para transformar sorrisos e proporcionar uma experiência odontológica mais segura, acolhedora e personalizada."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-9 flex flex-col gap-3 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "lg",
						className: "h-13 rounded-full px-7 text-base",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#contato",
							children: ["Agendar minha consulta ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "ml-1 size-4" })]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "lg",
						variant: "outline",
						className: "h-13 rounded-full border-primary/30 bg-background px-7 text-base text-primary hover:bg-soft",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#clinica",
							children: "Conhecer a clínica"
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-10 flex flex-wrap gap-x-8 gap-y-4",
					children: indicadores.map(({ icon: Icon, label }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-2 text-sm font-medium text-deep",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-4 shrink-0 text-primary",
							"aria-hidden": "true"
						}), label]
					}, label))
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: 120,
				className: "relative",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto max-w-md lg:max-w-none",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute -inset-4 rounded-[2.5rem] bg-soft/70",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative overflow-hidden rounded-[2rem] bg-background shadow-[0_24px_60px_-30px_oklch(0.443_0.101_243.5_/_0.45)]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: img.dentistaJaleco,
								alt: "Profissional da Sorriso Clin de jaleco branco em frente à fachada da clínica",
								className: "aspect-[4/5] w-full object-cover object-top",
								width: 1080,
								height: 1920,
								fetchPriority: "high"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute -bottom-6 -left-4 rounded-2xl border border-border bg-background px-5 py-4 shadow-lg sm:left-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl font-extrabold text-deep",
								children: "4,5 ★"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "27 avaliações no Google"
							})]
						})
					]
				})
			})]
		})]
	});
}
var itens = [
	{
		valor: "[A CONFIRMAR]",
		label: "Anos de experiência"
	},
	{
		valor: "4,5 ★",
		label: "Avaliação no Google"
	},
	{
		valor: "27",
		label: "Avaliações"
	},
	{
		valor: "Várzea Grande",
		label: "MT"
	}
];
function TrustBar() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		"aria-label": "Indicadores de confiança",
		className: "border-y border-border bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto grid max-w-7xl grid-cols-2 gap-y-8 px-4 py-10 sm:px-6 lg:grid-cols-4 lg:py-12",
			children: itens.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				delay: i * 70,
				className: "px-2 text-center lg:border-r lg:border-border lg:last:border-r-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl leading-tight font-extrabold text-deep sm:text-3xl",
					children: item.valor
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs tracking-wide text-muted-foreground uppercase sm:text-sm",
					children: item.label
				})]
			}, item.label))
		})
	});
}
var pilares = [
	{
		icon: HeartPulse,
		titulo: "Cuidado",
		texto: "Tecnologia e dedicação para realizar o melhor para você."
	},
	{
		icon: ShieldCheck,
		titulo: "Resultado",
		texto: "Transformações que vão além da estética."
	},
	{
		icon: UserRound,
		titulo: "Exclusividade",
		texto: "Cada sorriso é único. Cada paciente é especial."
	}
];
function Transformamos() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "transformacoes",
		className: "bg-background py-20 lg:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					className: "mx-auto max-w-3xl text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-3xl font-extrabold sm:text-4xl lg:text-5xl",
							children: "Transformamos sorrisos. Transformamos histórias."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-base leading-relaxed text-muted-foreground sm:text-lg",
							children: "Mais que estética, cada transformação representa confiança, autoestima e qualidade de vida."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArcDivider, { className: "mt-8" })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					delay: 100,
					className: "mt-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
						className: "mx-auto max-w-4xl overflow-hidden rounded-[2rem] border border-border bg-ice",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: img.antesDepois,
							alt: "Comparativo antes e depois de reabilitação de sorriso realizada na Sorriso Clin",
							className: "w-full object-cover",
							width: 1254,
							height: 1254,
							loading: "lazy"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-center text-xs text-muted-foreground",
						children: "Resultados individuais podem variar."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-14 grid gap-8 sm:grid-cols-3 sm:gap-10",
					children: pilares.map(({ icon: Icon, titulo, texto }, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						as: "li",
						delay: i * 90,
						className: "text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mx-auto grid size-14 place-items-center rounded-full bg-soft text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-6",
									"aria-hidden": "true"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-5 font-display text-lg font-bold",
								children: titulo
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted-foreground",
								children: texto
							})
						]
					}, titulo))
				})
			]
		})
	});
}
var blocos = [
	{
		icon: Award,
		titulo: "Experiência",
		texto: "Conhecimento e experiência para cuidar de cada etapa do seu tratamento."
	},
	{
		icon: Cpu,
		titulo: "Tecnologia",
		texto: "Recursos modernos para auxiliar em avaliações e planejamentos mais precisos."
	},
	{
		icon: HandHeart,
		titulo: "Humanização",
		texto: "Um atendimento próximo, cuidadoso e pensado para cada paciente."
	},
	{
		icon: Smile,
		titulo: "Transformação",
		texto: "Resultados que buscam devolver confiança para sorrir."
	}
];
function Diferenciais() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-ice py-20 lg:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				className: "max-w-2xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-3xl font-extrabold sm:text-4xl",
					children: "Por que escolher a Sorriso Clin?"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-12 grid gap-px overflow-hidden rounded-3xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-4",
				children: blocos.map(({ icon: Icon, titulo, texto }, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					as: "li",
					delay: i * 80,
					className: "group bg-background p-8 transition-colors hover:bg-background",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-6 text-primary transition-transform duration-300 group-hover:scale-105",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-6 font-display text-lg font-bold",
							children: titulo
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted-foreground",
							children: texto
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-6 block h-0.5 w-8 bg-magenta/70 transition-all duration-300 group-hover:w-14" })
					]
				}, titulo))
			})]
		})
	});
}
function FormaDeCuidar() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "clinica",
		className: "bg-background py-20 lg:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-2 lg:gap-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				className: "relative order-2 lg:order-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative overflow-hidden rounded-[2rem]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: img.profissionalMagenta,
						alt: "Profissional da Sorriso Clin com uniforme magenta durante atendimento",
						className: "aspect-[4/5] w-full object-cover",
						width: 1080,
						height: 1920,
						loading: "lazy"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arc, {
					className: "absolute -bottom-6 left-1/2 h-10 w-3/4 -translate-x-1/2 text-magenta/60",
					width: 4
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				delay: 100,
				className: "order-1 lg:order-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-[0.18em] text-magenta uppercase",
						children: "Nossa forma de cuidar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-5 text-3xl leading-tight font-extrabold sm:text-4xl",
						children: "Seu tratamento começa antes da cadeira odontológica."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 font-display text-lg font-semibold text-primary",
						children: "Começa no acolhimento. Na escuta. Na confiança."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-base leading-relaxed text-muted-foreground",
						children: "Na Sorriso Clin, acreditamos que um bom atendimento vai além do procedimento. Cada paciente possui uma história, uma necessidade e um objetivo diferente."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-base leading-relaxed text-muted-foreground",
						children: "Por isso, buscamos oferecer uma experiência personalizada desde o primeiro contato."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "lg",
						variant: "outline",
						className: "mt-9 h-12 rounded-full border-primary/30 px-7 text-primary hover:bg-soft",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#galeria",
							children: "Conheça nossa clínica"
						})
					})
				]
			})]
		})
	});
}
var etapas = [
	{
		n: "01",
		titulo: "Avaliação detalhada"
	},
	{
		n: "02",
		titulo: "Planejamento personalizado"
	},
	{
		n: "03",
		titulo: "Acompanhamento da evolução"
	}
];
function Tecnologia() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-deep py-20 text-deep-foreground lg:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-2 lg:gap-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-[0.18em] text-deep-foreground/70 uppercase",
					children: "Tecnologia"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-5 text-3xl leading-tight font-extrabold text-deep-foreground sm:text-4xl",
					children: "Precisão para enxergar cada detalhe."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-lg font-semibold text-deep-foreground/90",
					children: "A tecnologia faz parte da nossa forma de cuidar."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-xl leading-relaxed text-deep-foreground/75",
					children: "Recursos de avaliação e documentação podem auxiliar na análise, planejamento e acompanhamento de cada tratamento."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-10 space-y-6",
					children: etapas.map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						as: "li",
						delay: i * 90,
						className: "flex items-center gap-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-2xl font-extrabold text-deep-foreground/35",
								children: e.n
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-deep-foreground/20" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-right text-sm font-semibold text-deep-foreground sm:text-base",
								children: e.titulo
							})
						]
					}, e.n))
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: 120,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-hidden rounded-[2rem]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: img.fotografiaOdonto,
						alt: "Câmera fotográfica registrando o sorriso de um paciente durante documentação odontológica",
						className: "aspect-[4/5] w-full object-cover",
						width: 1237,
						height: 1416,
						loading: "lazy"
					})
				})
			})]
		})
	});
}
var tratamentos = [
	{
		icon: Sparkles,
		nome: "Estética Dental",
		desc: "Categoria estrutural sugerida — escopo e procedimentos [A CONFIRMAR] pela clínica."
	},
	{
		icon: Anchor,
		nome: "Implantes",
		desc: "Categoria estrutural sugerida — escopo e procedimentos [A CONFIRMAR] pela clínica."
	},
	{
		icon: Layers,
		nome: "Próteses",
		desc: "Categoria estrutural sugerida — escopo e procedimentos [A CONFIRMAR] pela clínica."
	},
	{
		icon: AlignHorizontalDistributeCenter,
		nome: "Ortodontia",
		desc: "Categoria estrutural sugerida — escopo e procedimentos [A CONFIRMAR] pela clínica."
	},
	{
		icon: Sun,
		nome: "Clareamento",
		desc: "Categoria estrutural sugerida — escopo e procedimentos [A CONFIRMAR] pela clínica."
	},
	{
		icon: Stethoscope,
		nome: "Dentística",
		desc: "Categoria estrutural sugerida — escopo e procedimentos [A CONFIRMAR] pela clínica."
	}
];
function Tratamentos() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "tratamentos",
		className: "bg-background py-20 lg:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-[0.18em] text-primary uppercase",
						children: "Tratamentos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-5 text-3xl font-extrabold sm:text-4xl",
						children: "Encontre o cuidado que seu sorriso precisa."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-5 text-sm text-muted-foreground",
						children: [
							"As categorias abaixo são estruturais. A lista oficial de tratamentos oferecidos está",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "font-semibold text-magenta",
								children: "[A CONFIRMAR]"
							}),
							" pela clínica."
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
				children: tratamentos.map(({ icon: Icon, nome, desc }, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					as: "li",
					delay: i % 3 * 80,
					className: "group flex flex-col rounded-2xl border border-border bg-background p-7 transition-all duration-300 hover:-translate-y-0.5 hover:border-primary/40",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-11 place-items-center rounded-xl bg-ice text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								"aria-hidden": "true"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-5 font-display text-lg font-bold",
							children: nome
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 flex-1 text-sm leading-relaxed text-muted-foreground",
							children: desc
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "ghost",
							className: "mt-5 h-11 w-fit px-0 text-primary hover:bg-transparent hover:text-deep",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#contato",
								"aria-label": `Saiba mais sobre ${nome}`,
								children: "Saiba mais →"
							})
						})
					]
				}, nome))
			})]
		})
	});
}
var equipe = [{
	foto: img.dentistaJaleco,
	alt: "Profissional da Sorriso Clin de jaleco branco em frente à clínica",
	nome: "[Nome a confirmar]",
	especialidade: "[Especialidade a confirmar]",
	cro: "CRO [a confirmar]",
	bio: "Apresentação profissional [A CONFIRMAR] pela clínica.",
	objeto: "object-top"
}, {
	foto: img.profissionalMagenta,
	alt: "Profissional da Sorriso Clin com uniforme magenta em ambiente clínico",
	nome: "[Nome a confirmar]",
	especialidade: "[Especialidade a confirmar]",
	cro: "CRO [a confirmar]",
	bio: "Apresentação profissional [A CONFIRMAR] pela clínica.",
	objeto: "object-center"
}];
function Equipe() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "equipe",
		className: "bg-ice py-20 lg:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-[0.18em] text-primary uppercase",
						children: "Equipe"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-5 text-3xl font-extrabold sm:text-4xl",
						children: "Quem está por trás de cada sorriso."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-5 text-sm text-muted-foreground",
						children: [
							"Nomes, especialidades e registros profissionais estão",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "font-semibold text-magenta",
								children: "[A CONFIRMAR]"
							}),
							" pela clínica."
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-3",
				children: equipe.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					as: "li",
					delay: i * 90,
					className: "overflow-hidden rounded-3xl border border-border bg-background",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: p.foto,
						alt: p.alt,
						className: `aspect-[3/4] w-full object-cover ${p.objeto}`,
						width: 1080,
						height: 1440,
						loading: "lazy"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-lg font-bold",
								children: p.nome
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm font-medium text-primary",
								children: p.especialidade
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-muted-foreground",
								children: p.bio
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-xs tracking-wide text-muted-foreground uppercase",
								children: p.cro
							})
						]
					})]
				}, i))
			})]
		})
	});
}
function Resultados() {
	const [pos, setPos] = (0, import_react.useState)(50);
	const areaRef = (0, import_react.useRef)(null);
	const dragging = (0, import_react.useRef)(false);
	const setFromClientX = (0, import_react.useCallback)((clientX) => {
		const el = areaRef.current;
		if (!el) return;
		const rect = el.getBoundingClientRect();
		const pct = (clientX - rect.left) / rect.width * 100;
		setPos(Math.min(100, Math.max(0, pct)));
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "resultados",
		className: "bg-background py-20 lg:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-[0.18em] text-primary uppercase",
						children: "Resultados"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-5 text-3xl font-extrabold sm:text-4xl",
						children: "Resultados que falam por si."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-base text-muted-foreground",
						children: "Arraste para comparar o antes e o depois de um caso real atendido na Sorriso Clin."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				delay: 100,
				className: "mt-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: areaRef,
					className: "relative mx-auto max-w-3xl touch-none overflow-hidden rounded-[2rem] border border-border select-none",
					onPointerDown: (e) => {
						dragging.current = true;
						e.currentTarget.setPointerCapture(e.pointerId);
						setFromClientX(e.clientX);
					},
					onPointerMove: (e) => dragging.current && setFromClientX(e.clientX),
					onPointerUp: () => dragging.current = false,
					onPointerCancel: () => dragging.current = false,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: img.casoDepois,
							alt: "Sorriso do paciente depois do tratamento reabilitador na Sorriso Clin",
							className: "aspect-[6/5] w-full object-cover",
							width: 570,
							height: 450,
							loading: "lazy"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-y-0 left-0 overflow-hidden",
							style: { width: `${pos}%` },
							"aria-hidden": "true",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: img.casoAntes,
								alt: "",
								className: "aspect-[6/5] h-full w-auto max-w-none object-cover",
								style: { width: areaRef.current ? `${areaRef.current.clientWidth}px` : "100%" },
								loading: "lazy"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute top-4 left-4 rounded-full bg-deep/85 px-3 py-1 text-xs font-semibold text-deep-foreground",
							children: "Antes"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute top-4 right-4 rounded-full bg-primary/90 px-3 py-1 text-xs font-semibold text-primary-foreground",
							children: "Depois"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-y-0 w-0.5 bg-background/90",
							style: { left: `${pos}%` },
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "range",
							min: 0,
							max: 100,
							value: Math.round(pos),
							onChange: (e) => setPos(Number(e.target.value)),
							"aria-label": "Comparar antes e depois",
							className: "absolute inset-x-0 bottom-0 h-11 w-full cursor-ew-resize opacity-0"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pointer-events-none absolute top-1/2 grid size-11 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-background text-primary shadow-lg",
							style: { left: `${pos}%` },
							"aria-hidden": "true",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoveHorizontal, { className: "size-5" })
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-center text-xs text-muted-foreground",
					children: "Resultados individuais podem variar."
				})]
			})]
		})
	});
}
var depoimentos = [
	{
		texto: "[Depoimento a confirmar pela clínica]",
		autor: "[Paciente]"
	},
	{
		texto: "[Depoimento a confirmar pela clínica]",
		autor: "[Paciente]"
	},
	{
		texto: "[Depoimento a confirmar pela clínica]",
		autor: "[Paciente]"
	}
];
function Depoimentos() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-ice py-20 lg:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-[0.18em] text-primary uppercase",
						children: "Depoimentos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-5 text-3xl font-extrabold sm:text-4xl",
						children: "Histórias de quem voltou a sorrir."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-5 flex items-center gap-2 text-sm text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
								className: "size-4 fill-magenta text-magenta",
								"aria-hidden": "true"
							}),
							clinica.nota,
							" de média em ",
							clinica.avaliacoes,
							" avaliações no Google."
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-12 grid gap-6 lg:grid-cols-3",
				children: depoimentos.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					as: "li",
					delay: i * 80,
					className: "rounded-3xl border border-border bg-background p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quote, {
							className: "size-6 text-magenta/70",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-sm leading-relaxed text-muted-foreground",
							children: d.texto
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 font-display text-sm font-bold text-deep",
							children: d.autor
						})
					]
				}, i))
			})]
		})
	});
}
var fotos = [
	{
		src: img.sedacao,
		alt: "Paciente em atendimento com sedação consciente na Sorriso Clin",
		span: "sm:col-span-2 sm:row-span-2"
	},
	{
		src: img.sorrisoPaciente,
		alt: "Close do sorriso de uma paciente da Sorriso Clin",
		span: ""
	},
	{
		src: img.fotografiaOdonto,
		alt: "Documentação fotográfica do sorriso em equipamento profissional",
		span: ""
	}
];
function Galeria() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "galeria",
		className: "bg-background py-20 lg:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				className: "max-w-2xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-[0.18em] text-primary uppercase",
					children: "A clínica"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-5 text-3xl font-extrabold sm:text-4xl",
					children: "Um ambiente pensado para o seu conforto."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 grid auto-rows-[180px] gap-4 sm:auto-rows-[200px] sm:grid-cols-4",
				children: fotos.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * 80,
					className: `overflow-hidden rounded-2xl ${f.span}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: f.src,
						alt: f.alt,
						className: "size-full object-cover transition-transform duration-500 hover:scale-[1.03]",
						loading: "lazy"
					})
				}, i))
			})]
		})
	});
}
function CTAFinal() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden bg-primary py-20 text-primary-foreground lg:py-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arc, {
			className: "absolute -bottom-10 left-1/2 h-40 w-[130%] -translate-x-1/2 text-primary-foreground/20",
			width: 2
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative mx-auto max-w-3xl px-4 text-center sm:px-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-3xl font-extrabold text-primary-foreground sm:text-4xl",
					children: "Seu novo sorriso pode começar hoje."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 text-base text-primary-foreground/85 sm:text-lg",
					children: "Agende uma avaliação na Sorriso Clin e descubra o cuidado que o seu sorriso merece."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-9 flex flex-col justify-center gap-3 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "lg",
						className: "h-13 rounded-full bg-background px-7 text-base text-primary hover:bg-ice",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: clinica.telefoneLink,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
									className: "mr-1 size-4",
									"aria-hidden": "true"
								}),
								" ",
								clinica.telefone
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "lg",
						variant: "outline",
						className: "h-13 rounded-full border-primary-foreground/40 bg-transparent px-7 text-base text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#contato",
							children: ["Ver localização ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
								className: "ml-1 size-4",
								"aria-hidden": "true"
							})]
						})
					})]
				})
			] })
		})]
	});
}
function Contato() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "contato",
		className: "bg-ice py-20 lg:py-28",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-2 lg:gap-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-[0.18em] text-primary uppercase",
					children: "Contato"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-5 text-3xl font-extrabold sm:text-4xl",
					children: "Venha nos visitar."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-9 space-y-6 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
								className: "mt-0.5 size-5 shrink-0 text-primary",
								"aria-hidden": "true"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "block font-semibold text-deep",
										children: "Endereço"
									}),
									clinica.endereco,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									clinica.bairro,
									" — CEP ",
									clinica.cep
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
								className: "mt-0.5 size-5 shrink-0 text-primary",
								"aria-hidden": "true"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "block font-semibold text-deep",
									children: "Telefone"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: clinica.telefoneLink,
									className: "hover:text-primary",
									children: clinica.telefone
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Instagram, {
								className: "mt-0.5 size-5 shrink-0 text-primary",
								"aria-hidden": "true"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "block font-semibold text-deep",
									children: "Instagram"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: clinica.instagram,
									target: "_blank",
									rel: "noreferrer",
									className: "break-words hover:text-primary",
									children: "@sorrisoclin_varzeagrande"
								})]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-6 text-sm text-muted-foreground",
					children: [
						"Horário de funcionamento:",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "font-semibold text-magenta",
							children: "[A CONFIRMAR]"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-col gap-3 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "lg",
						className: "h-12 rounded-full px-7",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: clinica.telefoneLink,
							children: "Ligar para a clínica"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "lg",
						variant: "outline",
						className: "h-12 rounded-full border-primary/30 bg-background px-7 text-primary hover:bg-soft",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: clinica.mapsRota,
							target: "_blank",
							rel: "noreferrer",
							children: "Como chegar"
						})
					})]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: 100,
				className: "overflow-hidden rounded-[2rem] border border-border bg-background",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
					src: clinica.mapsEmbed,
					title: `Mapa com a localização da ${clinica.nome} em Várzea Grande`,
					className: "h-80 w-full lg:h-full lg:min-h-[420px]",
					loading: "lazy",
					referrerPolicy: "no-referrer-when-downgrade"
				})
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: img.logo,
			alt: "",
			"aria-hidden": "true",
			className: "sr-only"
		})]
	});
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "bg-deep py-14 text-deep-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-[1.2fr_1fr_1fr]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: img.logoBranco,
					alt: "Logo Sorriso Clin",
					className: "h-10 w-auto",
					width: 936,
					height: 324
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 max-w-sm text-sm leading-relaxed text-deep-foreground/70",
					children: "Odontologia com experiência, tecnologia e cuidado humano em Várzea Grande — MT."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					"aria-label": "Rodapé",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-sm font-bold tracking-wide uppercase",
						children: "Navegação"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-2 text-sm text-deep-foreground/75",
						children: nav.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: n.href,
							className: "hover:text-deep-foreground",
							children: n.label
						}) }, n.href))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-sm font-bold tracking-wide uppercase",
					children: "Contato"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 space-y-3 text-sm text-deep-foreground/75",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							clinica.endereco,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							clinica.bairro
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
								className: "size-4 shrink-0",
								"aria-hidden": "true"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: clinica.telefoneLink,
								className: "hover:text-deep-foreground",
								children: clinica.telefone
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Instagram, {
								className: "size-4 shrink-0",
								"aria-hidden": "true"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: clinica.instagram,
								target: "_blank",
								rel: "noreferrer",
								className: "hover:text-deep-foreground",
								children: "@sorrisoclin_varzeagrande"
							})]
						})
					]
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto mt-12 max-w-7xl border-t border-deep-foreground/15 px-4 pt-6 text-xs text-deep-foreground/60 sm:px-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"© ",
				(/* @__PURE__ */ new Date()).getFullYear(),
				" ",
				clinica.nome,
				". Todos os direitos reservados. Responsável técnico e CRO: ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-magenta",
					children: "[A CONFIRMAR]"
				}),
				"."
			] })
		})]
	});
}
function Index() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrustBar, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Transformamos, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Diferenciais, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormaDeCuidar, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tecnologia, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tratamentos, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Equipe, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Resultados, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Depoimentos, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Galeria, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CTAFinal, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Contato, {})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
//#endregion
export { Index as component };
